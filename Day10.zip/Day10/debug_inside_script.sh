#!/bin/bash 


set -x

echo "Starting script"
date
who
