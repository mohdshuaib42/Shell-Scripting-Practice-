#!/bin/bash
#

if [ ! -f "$1" ]
then
	echo "file not found"
	exit 1
fi
	echo "processing $1"

