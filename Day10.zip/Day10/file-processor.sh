#!/bin/bash 

set -x

if [ ! -f "$1" ]
then 
	echo "file not found"
	exit 1
else
	echo ""$1" file is being processded"
fi

