#!/bin/bash 

date > system.log 
df -h >> system.log
free -h >> system.log
