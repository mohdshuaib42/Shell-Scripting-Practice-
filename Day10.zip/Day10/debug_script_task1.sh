#!/bin/bash

num1=2
num2=49

sum=$(($num2 + $num3))

echo $sum
