#!/bin/bash 

read -p "Enter the directory name: " dirname

mkdir "$dirname"

if [ $? -eq 0 ]
then 
	echo ""$dirname" directory created successfuly."
else
	echo "Failed to create "$dirname" direcotry"
fi
