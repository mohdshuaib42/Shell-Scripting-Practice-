#!/bin/bash


num1=10
num2=5

sum=$(($sum1 + $sum3))

echo $sum


