#!/bin/bash 

logfile="script.log"

echo "Script started..."
df -h >> $logfile
echo "Script completed" >> $logfile
