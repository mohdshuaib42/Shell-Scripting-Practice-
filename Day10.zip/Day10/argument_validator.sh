#!/bin/bash 


if [ "$#" -eq 0 ]
then 
	echo "Usage: ./script.sh filename"
else
	echo "filename is ->> "$@""
fi
