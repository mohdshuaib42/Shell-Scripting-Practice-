#!/bin/bash 

mkdir test22

if [ $? -eq 0 ]
then 
	echo "Dir created"
else
	echo "Error"
fi
